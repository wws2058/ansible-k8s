#!/bin/bash
# check&add jumpservers ssh key
# TODO
exit 0
